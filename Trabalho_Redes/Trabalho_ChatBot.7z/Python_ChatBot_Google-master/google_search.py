import requests
import string
from lxml import html
from googlesearch import search
from bs4 import BeautifulSoup


def chatbot_query(query, index=0):
    fallback = 'Desculpe, não consigo pensar em uma resposta para isso.'
    result = ''

    try:

        #instancia query passando parametro de busca
        search_result_list = list(search(query, tld="co.in", num=10, stop=3, pause=1))

        #realiza a consulta na API utilizando a biblioteca requests
        page = requests.get(search_result_list[index])

        tree = html.fromstring(page.content)

        #chama o beatiful soup para a leitura da resposta da requisição como o endereço de busca
        soup = BeautifulSoup(page.content, features="lxml")

        #instancia a variavel que recebera o artigo
        article_text = ''
        article = soup.findAll('p')
        for element in article:
            article_text += '\n' + ''.join(element.findAll(text = True))
        article_text = article_text.replace('\n', '')
        first_sentence = article_text.split('.')
        first_sentence = first_sentence[0].split('?')[0]

        chars_without_whitespace = first_sentence.translate(
            { ord(c): None for c in string.whitespace }
        )

        if len(chars_without_whitespace) > 0:
            result = first_sentence
        else:
            result = fallback

        return result
    except:
        if len(result) == 0: result = fallback
        return result
